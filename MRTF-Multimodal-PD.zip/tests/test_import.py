def test_import():
    import mrtf
